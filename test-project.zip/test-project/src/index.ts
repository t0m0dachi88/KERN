import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import config from './config/config';
import authRoutes from './routes/auth';
import todoRoutes from './routes/todos';
import { errorHandler } from './middleware/errorHandler';

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/todos', todoRoutes);

// Error handling
app.use(errorHandler);

// Connect to MongoDB and start server
const start = async () => {
  try {
    await mongoose.connect(config.MONGO_URI);
    console.log('✅ Connected to MongoDB');
    app.listen(config.PORT, () => {
      console.log(`🚀 Server listening on port ${config.PORT}`);
    });
  } catch (err) {
    console.error('❌ Failed to connect to MongoDB', err);
    process.exit(1);
  }
};

start();
