import { Schema, model, Document, Types } from 'mongoose';
import { IUser } from './User';

export interface ITodo extends Document {
  title: string;
  description?: string;
  completed: boolean;
  user: Types.ObjectId | IUser;
}

const todoSchema = new Schema<ITodo>({
  title: { type: String, required: true },
  description: { type: String },
  completed: { type: Boolean, default: false },
  user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
}, { timestamps: true });

export default model<ITodo>('Todo', todoSchema);