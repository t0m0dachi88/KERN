import dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

interface Config {
  MONGO_URI: string;
  JWT_SECRET: string;
  PORT: number;
}

const config: Config = {
  MONGO_URI: process.env.MONGO_URI ?? '',
  JWT_SECRET: process.env.JWT_SECRET ?? '',
  PORT: Number(process.env.PORT) || 3000,
};

if (!config.MONGO_URI) {
  console.error('❌ MONGO_URI not defined in .env');
  process.exit(1);
}
if (!config.JWT_SECRET) {
  console.error('❌ JWT_SECRET not defined in .env');
  process.exit(1);
}

export default config;
