import { Request, Response } from 'express';
import Todo, { ITodo } from '../models/Todo';
import { Types } from 'mongoose';

export const createTodo = async (req: Request, res: Response) => {
  const { title, description } = req.body;
  const userId = (req as any).userId;
  const todo = new Todo({ title, description, user: userId });
  await todo.save();
  res.status(201).json(todo);
};

export const getTodos = async (req: Request, res: Response) => {
  const userId = (req as any).userId;
  const todos = await Todo.find({ user: userId });
  res.json(todos);
};

export const getTodoById = async (req: Request, res: Response) => {
  const { id } = req.params;
  if (!Types.ObjectId.isValid(id)) {
    return res.status(400).json({ error: 'Invalid ID' });
  }
  const todo = await Todo.findOne({ _id: id, user: (req as any).userId });
  if (!todo) {
    return res.status(404).json({ error: 'Todo not found' });
  }
  res.json(todo);
};

export const updateTodo = async (req: Request, res: Response) => {
  const { id } = req.params;
  const allowedUpdates: Partial<ITodo> = {}; 
  const updatableFields = ['title', 'description', 'completed'];
  for (const key of updatableFields) {
    if (key in req.body) {
      // @ts-ignore
      allowedUpdates[key] = req.body[key];
    }
  }
  if (!Types.ObjectId.isValid(id)) {
    return res.status(400).json({ error: 'Invalid ID' });
  }
  const todo = await Todo.findOneAndUpdate(
    { _id: id, user: (req as any).userId },
    allowedUpdates,
    { new: true, runValidators: true },
  );
  if (!todo) {
    return res.status(404).json({ error: 'Todo not found' });
  }
  res.json(todo);
};

export const deleteTodo = async (req: Request, res: Response) => {
  const { id } = req.params;
  if (!Types.ObjectId.isValid(id)) {
    return res.status(400).json({ error: 'Invalid ID' });
  }
  const todo = await Todo.findOneAndDelete({ _id: id, user: (req as any).userId });
  if (!todo) {
    return res.status(404).json({ error: 'Todo not found' });
  }
  res.json({ message: 'Deleted' });
};
