import { Router } from 'express';
import { createTodo, getTodos, getTodoById, updateTodo, deleteTodo } from '../controllers/todoController';
import { authenticate } from '../middleware/auth';
import { validateTodo, validateTodoUpdate } from '../middleware/validation';

const router = Router();

router.post('/', authenticate, validateTodo, createTodo);
router.get('/', authenticate, getTodos);
router.get('/:id', authenticate, getTodoById);
router.patch('/:id', authenticate, validateTodoUpdate, updateTodo);
router.delete('/:id', authenticate, deleteTodo);

export default router;
